#!/usr/bin/env python3

print(
    '''
    \Content-Type: text/html

    <!DOCTYPE html>
    <html lang="en">
    <body>
    <h1>Hello, World!</h1>
    </body>
    </html>
    '''
)